export const mockProducts = [
  {
    id: "p1",
    productName: "lays",
    supplier: "t",
    quantity: 5,
    price: 70.00,
    expiryDate: "12/23/2025",
    location: "2 - ferf",
  },
  {
    id: "p2",
    productName: "biscuit",
    supplier: "y",
    quantity: 31,
    price: 10.00,
    expiryDate: "10/31/2025",
    location: "e3ewd - pune maharashtra",
  },
];