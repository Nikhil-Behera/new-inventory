export const mockCustomers = [
  {
    id: "c1",
    name: "123",
    contact: "1234567891",
    address: "ertyuio",
    gstNumber: "N/A",
  },
  {
    id: "c2",
    name: "3",
    contact: "578909w23456789",
    address: "wsdfghjkml",
    gstNumber: "N/A",
  },
];