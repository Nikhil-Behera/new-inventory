export const mockOrders = [
  {
    id: "o1",
    challanId: "CH1761669060509",
    customer: "123",
    deliveryDate: "10/29/2025",
    items: 2,
    status: "Pending",
  },
];